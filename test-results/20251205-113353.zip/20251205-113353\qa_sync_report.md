﻿QA Sync Report

Time: 20251205-111507
Source: C:\InfinityWindow
QA Mirror: C:\InfinityWindow_QA
Excluded Dirs: .venv, node_modules, test-results, .cache, dist, build, playwright-report, .git, chroma_data, chroma_data.bak.20251203
Excluded Files: *.log, *.tmp, Thumbs.db, desktop.ini, *.sqlite3, *.db, *db-wal, *db-shm, chroma.sqlite3
Root Manifest SHA: A25786691AC9B9006CB9CDA4D03DC174CD75B959D4C478B66FBB61D7B46D8D04
QA Manifest SHA: A25786691AC9B9006CB9CDA4D03DC174CD75B959D4C478B66FBB61D7B46D8D04
Outcome: PASS

If FAIL, re-run the Robocopy mirror and/or list the first few differences by comparing the manifests.
